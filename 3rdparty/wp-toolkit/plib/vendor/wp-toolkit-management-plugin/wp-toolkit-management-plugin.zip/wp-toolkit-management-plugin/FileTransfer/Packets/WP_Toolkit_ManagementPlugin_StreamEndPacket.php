<?php
// Copyright 1999-2019. Plesk International GmbH. All rights reserved.

namespace PleskExt\WpToolkit\FileTransfer\Packets;

class StreamEndPacket
{
}
