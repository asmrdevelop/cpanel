
# Usage
# perl -MJSON -MPlesk::DatabaseDumper dump_databases_and_users.pl

package main;

our $VERSION = '1.0';

#
## No USE statements so this runs on other platforms
## We must require everything in AFTER the version line
##
#
if ( @ARGV && grep( m/version/i, @ARGV ) ) {
    print "dump_databases_and_users VERSION $VERSION\n";
    exit(0);
}

-f '/etc/trueuserdomains' or die "/etc/trueuserdomains is missing";

my $dumper = Plesk::DatabaseDumper->new();

my $master_map = $dumper->dump_users_and_dbs();

print JSON::PP::encode_json($master_map);
