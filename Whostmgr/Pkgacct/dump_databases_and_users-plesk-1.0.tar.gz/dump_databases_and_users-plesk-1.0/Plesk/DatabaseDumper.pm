package Plesk::DatabaseDumper;

use strict;
use warnings;
use IPC::Open3 ();

sub new {
    my ( $class, %OPTS ) = @_;

    my $self = {};

    bless $self, $class;

    $self->{'psa1'}                 = $self->get_psa1();
    $self->{'psaversion'}           = $self->getpsaversion();
    $self->{'adminpass'}            = $self->_get_adminpass();
    $self->{'is_smb10'}             = $self->check_if_is_smb10();
    $self->{'domains_and_users'}    = $self->get_plesk_domains_and_users();
    $self->{'domain_ids_and_names'} = $self->get_domain_ids_and_names();

    return $self;
}

sub dump_users_and_dbs {
    my ($self) = @_;

    my $master_map = {};

    while ( my ( $dns, $user ) = each( %{ $self->{'domains_and_users'} } ) ) {
        my $sysuserid = $self->psasqlcmd("select id from sys_users where login='$user';");
        next if !$sysuserid;

        my $domainid = $self->domainid( $dns, $sysuserid, $user );
        my $databases = $self->get_databases($domainid);

        my $sql = qq(
                select
                    db_users.login
                from
                    db_users
                    inner join data_bases on data_bases.id = db_users.db_id
                    inner join domains on data_bases.dom_id = domains.id
                where
                    data_bases.type = "mysql"
                    and domains.id = $domainid
            );

        my $dbusers = $self->psasqlcmd($sql);
        next if !$dbusers;
        chomp $dbusers;
        $dbusers =~ s/[\r\n]/ /;

        my @mysql_databases;

        if ( $self->{'psa1'} ) {
            push @mysql_databases, { 'name' => $user };
        }
        else {
            @mysql_databases = grep { $_->{'type'} eq 'mysql' } @{$databases};
        }

        next if !@mysql_databases;

        my @mydbs;
        for my $db (@mysql_databases) {
            push @mydbs, $db->{'name'};
        }
        my @myusers = split /\s/, $dbusers;

        @{ $master_map->{'users'}{'MYSQL'} }{@myusers} = ( ( { 'owner' => $user } ) x scalar @myusers );
        @{ $master_map->{'dbs'}{'MYSQL'} }{@mydbs}     = ( ( { 'owner' => $user } ) x scalar @mydbs );

        delete $master_map->{'users'}{'MYSQL'}{''};
        delete $master_map->{'dbs'}{'MYSQL'}{''};

    }

    return $master_map;
}

sub psasqlcmd {
    my ( $self, $query ) = @_;
    my $result;

    my $handle = $self->get_psasqlcmd_handle(
        $query,
        'no_column_names' => 1
    );

    while ( read( $handle->{'out'}, my $buf, 4096 ) ) {
        $result .= $buf;
    }

    close $handle->{'out'};
    waitpid( $handle->{'pid'}, 0 );

    return ($result);
}

sub get_psasqlcmd_handle {
    my ( $self, $query, %opts ) = @_;

    my $command = $self->find_mysql();
    my @args = ( $self->{'psa1'} ? 'plesk' : 'psa' );

    unshift @args, '-N' if $opts{'no_column_names'};

    my $err = Symbol::gensym();
    my $pid = IPC::Open3::open3( my ( $in, $out ), $err, $command, @args ) or die("Unable to run $command: $!");

    print {$in} "$query\n";
    close $in;

    #
    # Check to see if any error messages are pending on standard error.  If so,
    # collect them and terminate.
    #
    my $ready = '';
    my $check = '';

    vec( $check, fileno($out), 1 ) = 1;
    vec( $check, fileno($err), 1 ) = 1;
    if ( select( $ready = $check, undef, undef, undef ) && vec( $ready, fileno($err), 1 ) == 1 ) {
        my $message;

        while ( read( $err, my $buf, 4096 ) ) {
            $message .= $buf;
        }

        if ($message) {
            chomp $message;
            die("MySQL error: $message");
        }
    }

    close $err;

    return {
        'pid' => $pid,
        'out' => $out
    };
}

sub get_psa1 {
    my ($self) = @_;

    return -e "/etc/psa/.psa.shadow" ? 0 : 1;
}

sub find_mysql {
    my ($self) = @_;
    my ( @LOC, $loc );
    @LOC = ( "/usr/local/psa/mysql/bin/mysql", "/usr/bin/mysql", "/usr/sbin/mysql", "/usr/local/plesk/mysql/bin/mysql", "/usr/local/bin/mysql" );
    foreach $loc (@LOC) {
        if ( -e $loc ) { return $loc; }
    }
}

sub domainid {
    my ( $self, $dns, $sysuserid, $user ) = @_;

    if ( $self->{'psaversion'}->{'major'} >= 7 ) {
        return $self->psasqlcmd("select id from domains where name='$dns';");
    }
    elsif ( $self->{'psaversion'}->{'major'} == 6 ) {
        return $self->psasqlcmd("select dom_id from hosting where sys_user_id='$sysuserid';");
    }
    elsif ( $self->{'psaversion'}->{'major'} == 5 ) {
        return $self->psasqlcmd("select hosting.dom_id from hosting left join sys_users on hosting.sys_user_id=sys_users.id where sys_users.login='$user';");
    }
    else {
        return $self->psasqlcmd("select dom_id from hosting where login='$user';");
    }
}

sub get_domain_ids_and_names {
    my ($self) = @_;
    my $sql = qq( select id,name from domains order by id );

    my %domain_ids_and_names;
    my $output = $self->psasqlcmd($sql);
    foreach ( split( m{\n}, $output ) ) {
        if (m{ \A (\d+) \s+ (\S+) }xms) {
            $domain_ids_and_names{$1} = $2;
        }
    }

    return \%domain_ids_and_names;
}

sub getpsaversion {
    my ($self) = @_;
    my $psadir = getpsadir();
    my %version;

    ## pek NOTE: see /tmp/.../version
    open( PSAV, "${psadir}/version" );
    while (<PSAV>) {

        # We leave the version details undefined if we don't match a unsupported version
        if (/^ ([5-9]|1[0-1]) \.(\d+) \.(\d+) /x) {
            $version{'major'}   = $1;
            $version{'minor'}   = $2;
            $version{'release'} = $3;
        }
    }
    close(PSAV);

    return \%version;
}

sub getpsadir {
    my ($self) = @_;
    my ( @LOC, $loc );
    @LOC = ( "/usr/local/psa", "/usr/local/plesk", "/opt/psa" );
    foreach my $loc (@LOC) {
        if ( -e $loc ) { return $loc; }
    }
}

sub get_plesk_domains_and_users {
    my ($self) = @_;
    my $sql;

    my %plesk_domains_and_users;
    if ( defined $self->{'is_smb10'} || $self->{'psaversion'}->{'major'} < 10 ) {
        $sql = qq( 
                select
                    su.login as name,
                    d.name as domain,
                    d.id as domain_id,
                    d.cl_id as client_id
                from
                    domains d,
                    sys_users su,
                    hosting h
                where
                    d.id = h.dom_id
                    and su.id = h.sys_user_id
            );
    }
    else {
        $sql = qq(
                select
                    su.login as name,
                    d.name as domain,
                    d.id as domain_id,
                    d.cl_id as client_id
                from
                    domains d,
                    sys_users su,
                    hosting h
                where
                    su.id = h.sys_user_id
                    and h.dom_id = d.id
                    and d.webspace_id = 0
            );
    }

    my $output = $self->psasqlcmd($sql) or die "failed to execute: $sql";
    foreach ( split( m{\n}, $output ) ) {
        chomp;
        if (m{ \A (\S+) \s+ (\S+) }xms) {
            $plesk_domains_and_users{$2} = $1;
        }
    }

    return \%plesk_domains_and_users;
}

sub check_if_is_smb10 {
    my ($self) = @_;

    opendir( my $dh, '/etc/sw/keys/keys' );
    my @dir_contents = grep { !/^\.\.?$/ } readdir $dh;
    closedir $dh;

    my $is_smb10 = 0;
    if (@dir_contents) {
        my $plesk_key = pop @dir_contents;    # what if there is more than 1 key?

        open my $key_fh, '<', "/etc/sw/keys/keys/$plesk_key";
        while (<$key_fh>) {
            if (/Small Business Panel 10/) {
                $is_smb10 = 1;
                last;
            }
        }
        close $key_fh;
    }

    return $is_smb10;
}

sub _get_adminpass {
    my ($self) = @_;

    my $psa_pass_fh;

    if ( $self->{'psa1'} ) {
        open( $psa_pass_fh, '<', "/usr/local/plesk/admin/conf/admin.conf" );
    }
    else {
        open( $psa_pass_fh, '<', "/etc/psa/.psa.shadow" );
    }

    my $adminpass = readline($psa_pass_fh);
    chomp($adminpass);

    close($psa_pass_fh);

    return $adminpass;
}

sub get_databases {
    my ( $self, $domain_id ) = @_;

    $domain_id = int($domain_id);

    my $query;

    if ( $self->{'psaversion'}->{'major'} <= 7 ) {
        $query = qq(
            select
                db.name,
                db.type,
                dbu.login as user,
                ac.password as pass
            from
                data_bases db,
                db_users dbu,
                accounts ac
            where
                ac.id = dbu.account_id
                and dbu.db_id = db.id
                and db.dom_id = $domain_id
        );
    }
    else {
        $query = qq(
            select
                db.name,
                db.type,
                db.default_user_id,
                ds.host,
                ds.port,
                ds.admin_login as user,
                ds.admin_password as pass
            from
                data_bases db,
                DatabaseServers ds
            where
                ds.id = db.db_server_id
                and db.dom_id = $domain_id
        );
    }

    my $dbs = $self->psasqlcmd_hashref($query);
    #
    # It seems the actual password for the admin@localhost accounts stored
    # in the psa.DatabaseServers table is not stored, so update each row
    # fetched with the password retrieved from the Plesk environment prior
    # to returning.
    #
    foreach my $db ( @{$dbs} ) {
        next unless $db->{'user'} eq 'admin';
        next unless $db->{'host'} eq 'localhost';

        $db->{'pass'} = $self->{'adminpass'};
    }

    return $dbs;
}

sub psasqlcmd_hashref {
    my ( $self, $query ) = @_;
    my $data;

    my $handle = $self->get_psasqlcmd_handle($query);

    while ( read( $handle->{'out'}, my $buf, 4096 ) ) {
        $data .= $buf;
    }

    my @result_set;

    return \@result_set unless $data;

    my @mysql_data = split /\n/, $data;
    my @field_names = map lc, split( /\s+|\t+/, shift(@mysql_data) );

    foreach my $row (@mysql_data) {
        my @row = $self->_lexer($row);

        my $results = {};
        my $count   = 0;

        foreach my $field (@field_names) {
            $results->{$field} = $row[$count];
            $count++;
        }

        push @result_set, $results;
    }

    close $handle->{'out'};
    waitpid( $handle->{'pid'}, 0 );

    return \@result_set;
}

sub _lexer {
    my ( $self, $line ) = @_;
    $line =~ s/\s{2,}/ /;
    my $buffer;
    my @stash;
    my $in_double_quote = 0;
    my $in_single_quote = 0;
    foreach my $chr ( split //, $line ) {
        if ( $chr =~ /\"/ ) {
            $in_double_quote = !$in_double_quote;
        }
        if ( $chr =~ /\'/ ) {
            $in_single_quote = !$in_single_quote;
        }
        if ( $chr =~ /\s/ && ( !$in_double_quote && !$in_single_quote ) ) {
            push @stash, $buffer;
            $buffer = '';
        }
        else {
            $buffer .= $chr;
        }
    }
    return @stash, $buffer;
}

1;
